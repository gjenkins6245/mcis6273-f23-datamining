
### What do you wish to accomplish this semester in Data Mining?

- I wish to learn about the different **Python** libraries used in data mining.
- I wish to learn *best practices* of data mining.
- I wish to impletment the knowledge gained in this class in a final project or homework assignment to ensure I have learned as much as possible.